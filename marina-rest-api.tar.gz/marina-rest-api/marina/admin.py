from models import Boat, Slip
from django.contrib import admin


admin.site.register(Boat)
admin.site.register(Slip)
